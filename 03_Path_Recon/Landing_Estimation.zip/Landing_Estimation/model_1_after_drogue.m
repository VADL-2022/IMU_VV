
%% RAW PARAMETERS
imu_end_time = t_1; % uncertainty start time in s (visually determined)

%% MODEL #1: SIMULATE X TRAJECTORY AFTER DROGUE
% Initial parameters
[min111, imu_end_ii] = min(abs(imu_t - imu_end_time));
sim_end_t = imu_t(imu_N);

% Construct arrays
sim_t = (imu_end_time:dt:sim_end_t);
sim_N = length(sim_t);
sim_ax = zeros(1,sim_N);
sim_vx = zeros(1,sim_N);
sim_x = zeros(1,sim_N);

% Initialize acceleration, velocity, and displacement
sim_vx(1) = imu_vx(imu_end_ii);
sim_ax(1) = a_1; 
sim_x(1) = imu_x(imu_end_ii);
dV = sim_ax(1)*dt;

% Find acceleration, velocity, and displacement
for ii=1:sim_N-1
    [min222, imu_index] = min(abs(imu_t - sim_t(ii+1)));
    
    sim_x(ii+1) = sim_x(ii) + sim_vx(ii)*dt + 0.5*dV*dt;
    sim_vx(ii+1) = sim_vx(ii) + dV;
    
    if (abs(wind_profile_x(imu_index)) < abs(sim_vx(ii+1))) && ...
        (sign(wind_profile_x(imu_index)) == sign(sim_vx(ii+1)))
        sim_ax(ii+1) = -K*((wind_profile_x(imu_index)-sim_vx(ii+1))^2);
    else
        sim_ax(ii+1) = K*((wind_profile_x(imu_index)-sim_vx(ii+1))^2);
    end
    
    dV = sim_ax(ii+1)*dt;
end

% Combine IMU ascent with Model 1 (after drogue) simulation
t1 = horzcat(imu_t(1:imu_end_ii), sim_t);
ax1 = horzcat(imu_ax(1:imu_end_ii), sim_ax);
vx1 = horzcat(imu_vx(1:imu_end_ii), sim_vx);
x1 = horzcat(imu_x(1:imu_end_ii), sim_x);

