clear; clc; close all;

%% RAW PARAMETERS
dt = 0.001; 
a_1 = -2.5; % first acceleration point after dorgue (visually determined)
t_1 = 18.6; % time corresponding to a_1
a_2 = -1; % first acceleration point after dorgue (visually determined)
t_2 = 20.6; % time corresponding to a_2

%% FUNCTION CALLS
imu_process();
wind_density_profile();
model_1_after_drogue();
model_2_after_takeoff();

%% PLOTS

% X Displacement
figure(1)
hold on
plot(t1, x1,'linewidth', 1.2)
plot(t, x,'linewidth', 1.2)
hold off

ylabel('X Displacement (m)','interpreter','latex', 'FontSize', 16);
xlabel('Time (s)','interpreter','latex', 'FontSize', 16);
title('X Displacement vs Time',...
    'interpreter','latex', 'FontSize', 16);
legend('Model 1 (after drogue)', 'Model 2 (after takeoff)', ...
    'interpreter','latex','location','northeast','FontSize', 14);
grid on;
%{

% X Velocity
figure(2)
hold on
plot(t1, vx1,'linewidth', 1.2)
plot(t, vx,'linewidth', 1.2)
plot(imu_t, wind_profile_x,'linewidth', 1.2)
hold off

ylabel('X Velocity (m)','interpreter','latex', 'FontSize', 16);
xlabel('Time (s)','interpreter','latex', 'FontSize', 16);
title('X Velocity vs Time',...
    'interpreter','latex', 'FontSize', 16);
legend('Model 1 (after drogue)', 'Model 2 (after takeoff)', ...
    'Wind Profile',...
    'interpreter','latex','location','northeast','FontSize', 14);
grid on;


% X Acceleration
figure(3)
hold on
plot(t1, ax1,'linewidth', 1.2)
plot(t, ax,'linewidth', 1.2)
hold off

ylabel('X Acceleration (m)','interpreter','latex', 'FontSize', 16);
xlabel('Time (s)','interpreter','latex', 'FontSize', 16);
title('X Acceleration vs Time',...
    'interpreter','latex', 'FontSize', 16);
legend('Model 1 (after drogue)', 'Model 2 (after takeoff)', ...
    'interpreter','latex','location','northeast','FontSize', 14);
grid on;
xlim([16 25])


% Altitude
figure(4)
hold on
plot(imu_t, imu_alt,'linewidth', 1.2)
plot(t, z,'linewidth', 1.2)
hold off

ylabel('Altitude (m)','interpreter','latex', 'FontSize', 16);
xlabel('Time (s)','interpreter','latex', 'FontSize', 16);
title('Model 2 (after take-off): Altitude vs Time',...
    'interpreter','latex', 'FontSize', 16);
legend('IMU Pressure Altitude', 'Simulation Altitude', 'interpreter',...
    'latex','location','northeast','FontSize', 14);
grid on;
%}
